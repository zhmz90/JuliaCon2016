# This program is much slower than necessary because a small goof 
# causes Julia's type inference to deduce an abstract type
# See if you can fix it.

# Compute successor of i in its hailstone cycle
function h(i)
    if i%2==0
        i/2
    else
        3*i+1
    end
end

# Compute maximum value reached by hailstone cycles containing 2:k 
function hail(k)
    m = k
    for start=2:k
        n = start
        while n>=start
            n = h(n)
            m = max(m,n)
        end
    end
    m
end

@time hail(5000000)

#=
   Hint 1: Print the result of hail(5000).  Is there something 
   surprising about it?

   Hint 2: Try running "@code_warntype hail(10)".  
=#
