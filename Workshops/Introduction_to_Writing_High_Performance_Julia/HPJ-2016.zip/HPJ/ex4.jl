# J. Coder adapted the code below from
# en.wikipedia.org/wiki/Needleman-Wunsch_algorithm.
#
# J. Coder remembered to change 0-origin indexing to 1-origin indexing,
# but forgot another important adaptation inside function f_matrix 
# that can improve its performance on the order of 1.5x for the given
# problem size.  See if you can find it.
#
# Is there anything else you could do to speed up the computation?
function f_matrix(a,b,d,s)
    f = Array(Int32,length(a),length(b))
    for i=1:length(a)
        f[i,1] = d*(i-1)
    end
    for j=1:length(b)
        f[1,j] = d*(j-1)
    end
    for i=2:length(a), j=2:length(b)
        match = f[i-1,j-1] + s[a[i],b[j]]
        delete = f[i-1,j] + d
        insert = f[i,j-1] + d
        f[i,j] = max(match, insert, delete)
    end
    f
end

# TIMING HARNESS - DO NOT CHANGE CODE BELOW THIS LINE ------------------

# Make input for timing runs repeatable
srand(42)

# Create two random sequences 
n = 5000
a = rand(1:4,n)
b = rand(1:4,n)
s = Int32[10 -1 -3 -4
          -1  7 -5 -3
          -3 -5  9  0
          -4 -3  0  8]
d = 5

# Time routine f_matrix
checksum = 0
@time checksum += f_matrix(a,b,d,s)[end,end]
@time checksum += f_matrix(a,b,d,s)[end,end]
@time checksum += f_matrix(a,b,d,s)[end,end]
println("checksum = ", checksum)
