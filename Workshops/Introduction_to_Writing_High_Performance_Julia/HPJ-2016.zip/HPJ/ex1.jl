#= Function altsum has a big (~5x) performance problem arising
   from a type inference issue.  Try to fix it by changing 
   one line.

   Hint: try "@code_warntype altsum(a)".

   Does your fix improve or hurt the performance of altsum when
   applied to a Vector{Int}?
=#

# Compute alternating sum of array a
function altsum(a)
    s = 0
    c = 1
    for i in 1:length(a)
        s += c*a[i]
        c = -c
    end
    s
end

a = rand(1000000)

@time altsum(a)
@time altsum(a)

